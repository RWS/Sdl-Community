<table class="tip" align="center">
  <tr>
    <td><h1>System Fields</h1>
      <p><img src="SDLTMAnoymizer.Anonymize.SystemFields.gif" width="100%"></p>
<p>To learn more about how to anonymize <b>System Fields</b> in a Translation Memory, visit the <a href="https://community.sdl.com/product-groups/translationproductivity/w/customer-experience/3272.sdltmanonymizer#System_Fields">Online Help</a></p>   
     </td>	 
  </tr> 
</table>