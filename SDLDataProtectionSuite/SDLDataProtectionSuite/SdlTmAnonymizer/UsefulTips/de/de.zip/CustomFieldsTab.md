<table class="tip" align="center">
  <tr>
    <td><h1>Custom Fields</h1>
      <p><img src="SDLTMAnoymizer.Anonymize.CustomFields.gif" width="100%"></p>
<p>To learn more about how to anonymize <b>Custom Fields</b> in a Translation Memory, visit the <a href="https://community.sdl.com/product-groups/translationproductivity/w/customer-experience/3272.sdltmanonymizer#Custom_Fields">Online Help</a></p>   
     </td>	 
  </tr> 
</table>