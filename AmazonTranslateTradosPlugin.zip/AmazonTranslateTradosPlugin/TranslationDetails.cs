﻿namespace Sdl.Community.AmazonTranslateTradosPlugin
{
    public class TranslationDetails
    {
        public string Text { get; set; }
        public string To { get; set; }
    }
}
