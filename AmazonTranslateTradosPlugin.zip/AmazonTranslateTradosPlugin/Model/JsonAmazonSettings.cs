﻿namespace Sdl.Community.AmazonTranslateTradosPlugin.Model
{
	public class JsonAmazonSettings
	{
		public string RegionName { get; set; }
	}
}