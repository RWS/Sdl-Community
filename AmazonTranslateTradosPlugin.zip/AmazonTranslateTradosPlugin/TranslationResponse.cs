﻿using System.Collections.Generic;

namespace Sdl.Community.AmazonTranslateTradosPlugin
{
    public class TranslationResponse
    {
        public List<TranslationDetails> Translations { get; set; }
    }
}
