﻿using System.Collections.Generic;

namespace Sdl.Community.AmazonTranslateTradosPlugin
{
    public class Translation
    {
        public List<TranslationDetails> Translations { get; set; }
    }
}
