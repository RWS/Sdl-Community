﻿using System.Collections.Generic;

namespace Sdl.Community.AmazonTranslateTradosPlugin
{
    public class LanguageResponse
    {
        public Dictionary<string, LanguageDetails> Translation { get; set; }
    }
}
