using Sdl.Core.PluginFramework;

[assembly: Plugin("Plugin_Name")]



