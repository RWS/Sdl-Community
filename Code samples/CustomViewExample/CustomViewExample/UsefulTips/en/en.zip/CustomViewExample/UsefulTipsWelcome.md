# Welcome to the Custom Example View		

## Agenda for this demonstration
&#8226; Create a custom view that includes a navigation pane & content view part.  
&#8226; Add context aware documentation, in the form of Useful Tips within your plugin.  
