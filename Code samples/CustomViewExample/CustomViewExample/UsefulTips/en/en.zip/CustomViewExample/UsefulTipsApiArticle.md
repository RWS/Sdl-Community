# Include Useful Tips with your plugin
The `RwsAppStore.UsefulTips.Service` is a service provider for updating the Useful Tips that are displayed in Trados Studio.

***

## Add the Studio Useful Tips to your project
You can add the nuget package to your project via the package manager user interface or console.

### Package Manager UI
&#8226; In **Solution Explorer**, right-click **References** and choose **Manage NuGet Packages**.  
&#8226; Select nuget.org as the **Package source**.  
&#8226; Search for `RwsAppStore.UsefulTips.Service` from the **Browse** tab.  
&#8226; Select the package from the list and click **Install**.  
&#8226; Accept any license prompts to finnish the installation.  
<img style="display:block; " src="InstallFromNuget.png" />

### Package Manager Console 
&#8226;  Alternatively, go to **Tools** > **NuGet Package Manager** > **Package Manager Console**.  
&#8226; In the **Package Manager Console**, enter the command:  
`Install-Package RwsAppStore.UsefulTips.Service -Version 3.0.0.4`

***
  
## Remarks
The Useful Tips service first checks for already existing tips before attempting to add new ones. If tips exist in the Useful Tips collection, only those identified as new are added.  
If Trados Studio was not launched as administrator, the user may receive a message from the service asking to elevate the user rights before updating the Useful Tips collection in Trados Studio with the new tips from the plugin.  
**Note**    
Administrator rights are required, as the local tip files that manage the Useful Tips collection in Trados Studio reside in the Trados Studio installation directory.
Only a user with administrator access rights can modify files from the installation directory.  


### Settings
The Useful Tips service enables the user to hide the message that is displayed when new Tips are available for installation, by selecting the option '**Don't show this message again**'.  
This is necessary if the user did not update the Useful Tips collection when prompted in Trados Studio; in this case, the decision from the user will be persisted and no further attempt is made to add those tips for that version of Trados Studio.
<img style="display:block; " src="PromptMessage.png" />

**Q:** Where can I locate the _Settings.xml_ files of the Useful Tips service?  
**A:** The settings file is located in the users roaming directory:   
_C:\Users\\**[username]**\AppData\Roaming\RWS Community\UsefulTipsService\Settings_  
**NOTE**  
Replace **[username]** with your OS login account name  

**Q:** How can the user add tips from the plugin to the Useful Tips collection in Trados Studio if they previously opted-out to adding them?  
**A:** The decision taken by the user to prevent the prompt message from being displayed is persisted in the _Settings.xml_ file. To manually update this setting, simply open the _Settings.xml_ file in a text editor, search for the entry associated with the application and change the boolean value associated with the **HideInstallTipsMessage** property to 'false'.

~~~xml
<Settings>
  <Records>
    <Record>
      <ApplicationName>Application Name 1</ApplicationName>
      <TradosStudioVersion>16</TradosStudioVersion>
      <HideInstallTipsMessage>false</HideInstallTipsMessage>
    </Record>
    <Record>
      <ApplicationName>Application Name 2</ApplicationName>
      <TradosStudioVersion>15</TradosStudioVersion>
      <HideInstallTipsMessage>true</HideInstallTipsMessage>
    </Record>	
    <Record>
      <ApplicationName>Application Name 2</ApplicationName>
      <TradosStudioVersion>16</TradosStudioVersion>
      <HideInstallTipsMessage>false</HideInstallTipsMessage>
    </Record>
  </Records>
</Settings>
~~~