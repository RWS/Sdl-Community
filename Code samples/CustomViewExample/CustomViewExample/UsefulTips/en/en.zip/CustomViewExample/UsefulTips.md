# What are Useful Tips?

**Useful Tips** have been introduced in the Trados Studio interface so that you can have centralized access to videos, tips and tricks and other useful content that helps you learn how to use new or old features.  
  
Select the **Useful Tips** tab on the right-hand side of the interface and you will be presented with tips relevant to the Trados Studio view that you are currently in.  
  
All tips are also accessible by going to the **Help** tab and selecting **Useful Tips Collection**.  
