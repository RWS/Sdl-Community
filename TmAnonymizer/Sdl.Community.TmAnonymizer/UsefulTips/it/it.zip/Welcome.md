<table class="tip" align="center">
  <tr>
    <td><h1>Welcome to the SDLTM Anonymizer View</h1>
      <p>The SDLTM Anonymizer view is where you anonymize data in the both server and file-based Translation Memories. <br/>This is accomplished by identifying and replacing personal data with placeholders based on criteria such as regular expressions.
      <p>Watch this video to learn how to anonymize data in a TM, identifying & replacing content with placeholders</p>
      <table cellspacing="0" cellpadding="0" border="0" align="center" style="text-align: center;">
        <tr>
          <td style="border-radius: 7px; background: #25bd59; text-align: center;" class="button1-td"><a href="https://raw.githubusercontent.com/sdl/Sdl-Community/master/TmAnonymizer/Sdl.Community.TmAnonymizer/Resources/SDLTMAnoymizer.Anonymize.Data.gif" style="background: #25bd59; border: 10px solid #25bd59; font-family: 'Segoe UI', sans-serif; font-size: 16px; line-height: 1.1; text-align: center; text-decoration: none; display: block; border-radius: 7px; font-weight: normal;" class="button1-a"> <span style="color:#ffffff;">&nbsp;&nbsp;&nbsp;&nbsp;Watch the video&nbsp;&nbsp;&nbsp;&nbsp;</span> </a></td>
        </tr>
      </table></td>
  </tr>
</table>
