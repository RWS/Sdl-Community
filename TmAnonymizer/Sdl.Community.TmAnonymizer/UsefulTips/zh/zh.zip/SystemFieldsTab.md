<table class="tip" align="center">
  <tr>
    <td><h1>System Fields</h1>
      <p><img src="SDLTMAnoymizer.Anonymize.SystemFields.gif" width="100%"></p>
<p>To learn more about how to anonymize data in a Translation Memory, visit the <a href="https://community.sdl.com/product-groups/translationproductivity/w/customer-experience/3272.sdltmanonymizer">Online Help</a></p>   
     </td>	 
  </tr> 
</table>